PATRICK THAIRU — PORTFOLIO WEBSITE

Preview:
Open index.html in a web browser.

Publish free with GitHub Pages:
1. Sign in or create an account at https://github.com/
2. Create a public repository named patrick-thairu-portfolio.
3. Upload index.html to the repository's main/root folder.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. GitHub will show your public website address after publishing.

Your link will look like:
https://YOUR-GITHUB-USERNAME.github.io/patrick-thairu-portfolio/
This is only an example format; it is not active yet.

Before publishing, verify your contact details and replace the sample project descriptions with real work you have completed. Remove any skill you cannot demonstrate.
